﻿Imports System.Net
Public Class Form1
    Dim WithEvents download As New WebClient
    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Microsoft%20Windows%20XP%20(''Whistler''%205.0.2202.0%20Professional%20Beta).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub download_DownloadFileCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.AsyncCompletedEventArgs) Handles download.DownloadFileCompleted
        ProgressBar1.Value = 0
        PictureBox1.Image = My.Resources.downloaddisabled
    End Sub

    Private Sub download_DownloadProgressChanged(ByVal sender As Object, ByVal e As System.Net.DownloadProgressChangedEventArgs) Handles download.DownloadProgressChanged
        ProgressBar1.Value = e.ProgressPercentage
        Label2.Text = e.BytesReceived & " Bytes of " & e.TotalBytesToReceive & " Bytes downloaded"
        Label3.Text = e.ProgressPercentage & "% downloaded"
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        download.CancelAsync()
        ProgressBar1.Value = 0
        Label2.Text = "Download cancelled"
        Label3.Text = "Download cancelled"
        PictureBox1.Image = My.Resources.downloaddisabled
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.00.2211.1.main.000309-1512_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2223.1.main.000411-2307_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2250.1.main.000628-2110_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2257.1%20Home%20Beta).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click

        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2267.1.idx01.000910-1316_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2276.1%20Professional%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia903206.us.archive.org/7/items/windows-whistler-collection/5.1.2287.1.beta1.001012-1643_x86fre_client-professional_retail_en-us-WB1PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2296.1%20Professional%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2410.1.main.001208-1937_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2416.1%20Professional%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2419.1%20Professional%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2428.1.idx01.010129-1827_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2430.1.main.010130-1821_x86fre_client-professional_retail_en-us-WB2PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia903206.us.archive.org/7/items/windows-whistler-collection/5.1.2433.1.main.010206-1822_x86fre_client-personal_retail_en-us-WB2PLFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2446.1%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2454.1%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia903206.us.archive.org/7/items/windows-whistler-collection/5.1.2455.0.main.010307-1659_x86fre_client-professional_retail_en-us-VERVERA.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button21.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia903206.us.archive.org/7/items/windows-whistler-collection/5.1.2457.0.main.010309-1904_x86fre_client-personal_retail_en-us-WB2PLFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button22.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2458.0%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button23.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia903206.us.archive.org/7/items/windows-whistler-collection/5.1.2459.0.main.010312-1811_x86fre_client-professional_retail_en-us-WB2PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button24.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2462.0.main.010315-1739_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button25.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2463.0.main.010328-1824_x86fre_client-professional_retail_en-us-WB2PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button26.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2464.0.main.010405-1517_x86fre_client-professional_retail_en-us-ERIKAHERCEG.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button27.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2465.0%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button28.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2467.0.main.010418-1202_x86fre_client-professional_retail_en-us-LOPEZ_JENNIFER.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button29.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2469.0.idx02.010508-1228_x86fre_client-professional_retail_en-us-WB2PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button30.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2474.0%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button31.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2475.0.idx01.010514-2023_x86fre_client-professional_retail_en-us-WB2PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button32.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2481.0%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button34.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2486.0.main.010602-1927_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button35.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2494.0%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button33.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2485.0.main.010531-2130_x86fre_client-professional_retail_en-us-WR1PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button36_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button36.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2495.0%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button37_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button37.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2498.0.main.010618-1744_x86fre_client-home_retail_en-us-XR1PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button38.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2499.0%20Professional%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button39_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button39.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2502.0%20Professional%20RC1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button40.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2504.0%20Professional%20RC1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button41_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button41.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/whistler/5.1.2505.0.main.010626-1514_x86fre_client-professional_retail_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button43.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2517.0%20Professional%20RC1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button44_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button44.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2520.0%20Professional%20RC1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button45_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button45.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2525.0.xpclient.010723-1719_x86fre_client-professional_retail_en-us-XR2PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button46_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button46.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2526.0%20Professional%20RC1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button47_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button47.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2531.0%20Professional%20RC1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button48_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button48.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803206.us.archive.org/7/items/windows-whistler-collection/5.1.2532.0.xpclient.010731-1658_x86fre_client-professional_retail_en-us-XR2PFRE_EN.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button49_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button49.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2535.0%20Professional%20RC2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button50_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button50.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20'Whistler'/Microsoft%20Windows%20XP%20(''Whistler''%205.1.2542.0%20Professional%20RC2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button51_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button51.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/xp/professional/en_winxp_pro_x86_build2600_iso.img"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button52_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button52.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl.bobpony.com/windows/beta/chicago/4.00.58s_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button53_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button53.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Microsoft%20Windows%2095%20(Chicago%204.00.73f%20SDK).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button54_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button54.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.73g).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button55_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button55.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.81).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button57_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button57.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Microsoft%20Windows%2095%20(''Chicago''%204.00.90c).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button58_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button58.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Microsoft%20Windows%2095%20(Chicago%204.00.99).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button59_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button59.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl.winworldpc.com/Microsoft%20Windows%2095%20(''Chicago''%204.00.116)%20(ISO).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button60_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button60.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.122).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button61_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button61.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.180_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button62_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button62.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.189).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button63_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button63.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.216).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button64_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button64.Click

    End Sub
    Private Sub Button65_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button65.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.224).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button67_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button67.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Microsoft%20Windows%2095%20(Chicago%204.00.263).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button68_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button68.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.267).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button69_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button69.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.275).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button70_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button70.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.285_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button71_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button71.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.286_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button72_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button72.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.302_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button74_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button74.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.311_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button75_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button75.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.314_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button76_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button76.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.318_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button78_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button78.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.324_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button79_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button79.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1351%20B0).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Panel3_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel3.Paint

    End Sub

    Private Sub Button80_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button80.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1353_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button81_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button81.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1387%20B0).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button82_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button82.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1400%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button83_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button83.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1410_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button84_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button84.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1411_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button85_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button85.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1415_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button86_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button86.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1423%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button87_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button87.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1434_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button88_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button88.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1488%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button89_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button89.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1500_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button90_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button90.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1511%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button91_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button91.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1513_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button92_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button92.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1518_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button93_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button93.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1525%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button94_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button94.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia803409.us.archive.org/0/items/microsoft-windows-98-4.10.1526-1997-06-23-english-cd-beta-1.-7z/Microsoft%20Windows%2098%20%284.10.1526%29%20%281997-06-23%29%20%5BEnglish%5D%20%28CD%29%20%28beta1%29.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button95_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button95.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1532%20B1).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button96_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button96.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia904501.us.archive.org/28/items/microsoftwindowsmemphisbuild1351-1998collection73files/4.10.1538_x86fre_client_en-us-MEM_1538.iso"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button97_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button97.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1544_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button98_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button98.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2098%20'Memphis'/Microsoft%20Windows%2098%20(''Memphis''%204.10.1546%20B2).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button99_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button99.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1559_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button100_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button100.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1569_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button103_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button103.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.331_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button104_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button104.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.337_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button105_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button105.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.342_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button107_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button107.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.345_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button108_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button108.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://dl-alt1.winworldpc.com/Beta%20Operating%20Systems/PC/Microsoft%20Windows%2095%20'Chicago'/Microsoft%20Windows%2095%20(''Chicago''%204.00.347).7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button109_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button109.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.405_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button111_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button111.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/chicago/4.00.420_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button112_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button112.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1577_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button113_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button113.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1581.1_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button114_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button114.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1593_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button115_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button115.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1602_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button116_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button116.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1614_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button117_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button117.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1619_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button118_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button118.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("http://dl.bobpony.com/windows/beta/memphis/4.10.1624_x86fre_client_en-us.7z"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button120_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button120.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            download.DownloadFileAsync(New Uri("https://ia800702.us.archive.org/17/items/MicrosoftWindowsXPCodenameWhistler/%28Beta%29%20Operating%20Systems/PC/Microsoft%20Windows%20XP%20%28%27%27Whistler%27%27%29/5.1.2526.0/5.1.2526.0.xpclient.010724-1758_x86fre_client-embedded_en-us/media_iso.rar"), SaveFileDialog1.FileName)
            PictureBox1.Image = My.Resources.save
        End If
    End Sub

    Private Sub Button148_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class