﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button101 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.Button64 = New System.Windows.Forms.Button()
        Me.Button65 = New System.Windows.Forms.Button()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Button66 = New System.Windows.Forms.Button()
        Me.Button67 = New System.Windows.Forms.Button()
        Me.Button68 = New System.Windows.Forms.Button()
        Me.Button69 = New System.Windows.Forms.Button()
        Me.Button70 = New System.Windows.Forms.Button()
        Me.Button71 = New System.Windows.Forms.Button()
        Me.Button72 = New System.Windows.Forms.Button()
        Me.Button73 = New System.Windows.Forms.Button()
        Me.Button74 = New System.Windows.Forms.Button()
        Me.Button75 = New System.Windows.Forms.Button()
        Me.Button76 = New System.Windows.Forms.Button()
        Me.Button77 = New System.Windows.Forms.Button()
        Me.Button78 = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button111 = New System.Windows.Forms.Button()
        Me.Button110 = New System.Windows.Forms.Button()
        Me.Button109 = New System.Windows.Forms.Button()
        Me.Button108 = New System.Windows.Forms.Button()
        Me.Button107 = New System.Windows.Forms.Button()
        Me.Button105 = New System.Windows.Forms.Button()
        Me.Button104 = New System.Windows.Forms.Button()
        Me.Button103 = New System.Windows.Forms.Button()
        Me.Button102 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button118 = New System.Windows.Forms.Button()
        Me.Button117 = New System.Windows.Forms.Button()
        Me.Button116 = New System.Windows.Forms.Button()
        Me.Button115 = New System.Windows.Forms.Button()
        Me.Button114 = New System.Windows.Forms.Button()
        Me.Button113 = New System.Windows.Forms.Button()
        Me.Button112 = New System.Windows.Forms.Button()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Button100 = New System.Windows.Forms.Button()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.Button98 = New System.Windows.Forms.Button()
        Me.Button97 = New System.Windows.Forms.Button()
        Me.Button96 = New System.Windows.Forms.Button()
        Me.Button95 = New System.Windows.Forms.Button()
        Me.Button94 = New System.Windows.Forms.Button()
        Me.Button93 = New System.Windows.Forms.Button()
        Me.Button92 = New System.Windows.Forms.Button()
        Me.Button91 = New System.Windows.Forms.Button()
        Me.Button90 = New System.Windows.Forms.Button()
        Me.Button89 = New System.Windows.Forms.Button()
        Me.Button88 = New System.Windows.Forms.Button()
        Me.Button87 = New System.Windows.Forms.Button()
        Me.Button86 = New System.Windows.Forms.Button()
        Me.Button85 = New System.Windows.Forms.Button()
        Me.Button84 = New System.Windows.Forms.Button()
        Me.Button83 = New System.Windows.Forms.Button()
        Me.Button82 = New System.Windows.Forms.Button()
        Me.Button81 = New System.Windows.Forms.Button()
        Me.Button80 = New System.Windows.Forms.Button()
        Me.Button79 = New System.Windows.Forms.Button()
        Me.Button106 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Button119 = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button120 = New System.Windows.Forms.Button()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(5, 2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(704, 39)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Which Windows Beta you want to download?"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Panel1.Location = New System.Drawing.Point(-13, -75)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(731, 118)
        Me.Panel1.TabIndex = 2
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.ProgressBar1)
        Me.Panel3.Controls.Add(Me.Button3)
        Me.Panel3.Controls.Add(Me.PictureBox1)
        Me.Panel3.Location = New System.Drawing.Point(449, 41)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(269, 301)
        Me.Panel3.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 263)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(260, 26)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "NOTE: I'm not counting BetaArchive cuz BetaArchive" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "sucks." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "null% downloaded"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 91)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(173, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "null Bytes of null Bytes downloaded"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(3, 66)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(176, 22)
        Me.ProgressBar1.TabIndex = 6
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(185, 65)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Cancel"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.bDown.My.Resources.Resources.downloaddisabled
        Me.PictureBox1.Location = New System.Drawing.Point(1, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(260, 56)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = "ISO Image|*.iso|Archive|*.7z|Archive|*.zip|IMG Image|*.img|Archive|*.rar"
        Me.SaveFileDialog1.Title = "Save As..."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(246, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(197, 39)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "(?) means that it is unknown if it is" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Beta 1, Beta 2, Pre-RC1, RC1, Pre-RC2," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RC" & _
            "2, Pre-RTM or RTM."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(249, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(194, 39)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "If the file does not work," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "then try with these file extensions given:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ".iso, .7z" & _
            ", .zip, .img"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(287, 74)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 13)
        Me.Label8.TabIndex = 53
        Me.Label8.Text = "FUCK YOU"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(249, 135)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(179, 13)
        Me.Label9.TabIndex = 54
        Me.Label9.Text = "And MCS Means more coming soon."
        '
        'Button101
        '
        Me.Button101.Enabled = False
        Me.Button101.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button101.Location = New System.Drawing.Point(235, 282)
        Me.Button101.Name = "Button101"
        Me.Button101.Size = New System.Drawing.Size(211, 37)
        Me.Button101.TabIndex = 52
        Me.Button101.Text = "Windows Chicago"
        Me.Button101.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Enabled = False
        Me.Button1.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(12, 282)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(211, 37)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Windows Whistler"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(3, 34)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(158, 23)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "Build 2202 Beta 1"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(3, 58)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(158, 23)
        Me.Button4.TabIndex = 1
        Me.Button4.Text = "Build 2211 Beta 1"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(3, 83)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(158, 23)
        Me.Button5.TabIndex = 2
        Me.Button5.Text = "Build 2223 Beta 1"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(3, 108)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(158, 23)
        Me.Button6.TabIndex = 3
        Me.Button6.Text = "Build 2250 Beta 1"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(3, 131)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(158, 23)
        Me.Button7.TabIndex = 4
        Me.Button7.Text = "Build 2257 Beta 1"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(3, 156)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(158, 23)
        Me.Button8.TabIndex = 5
        Me.Button8.Text = "Build 2267 Beta 1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(3, 180)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(158, 23)
        Me.Button9.TabIndex = 6
        Me.Button9.Text = "Build 2276 Beta 1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(3, 204)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(158, 23)
        Me.Button10.TabIndex = 7
        Me.Button10.Text = "Build 2287 Beta 1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(3, 229)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(158, 23)
        Me.Button11.TabIndex = 8
        Me.Button11.Text = "Build 2296 Beta 1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(3, 255)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(158, 23)
        Me.Button12.TabIndex = 9
        Me.Button12.Text = "Build 2410 Beta 1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(3, 279)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(158, 23)
        Me.Button13.TabIndex = 10
        Me.Button13.Text = "Build 2416 Beta 1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(3, 303)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(158, 23)
        Me.Button14.TabIndex = 11
        Me.Button14.Text = "Build 2419 Beta 1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(3, 329)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(158, 23)
        Me.Button15.TabIndex = 12
        Me.Button15.Text = "Build 2428 Beta 2"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(3, 353)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(158, 23)
        Me.Button16.TabIndex = 13
        Me.Button16.Text = "Build 2430 Beta 2"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(3, 379)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(158, 23)
        Me.Button17.TabIndex = 14
        Me.Button17.Text = "Build 2433 Beta 2"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(3, 404)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(158, 23)
        Me.Button18.TabIndex = 15
        Me.Button18.Text = "Build 2446 Beta 2"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(3, 433)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(158, 23)
        Me.Button19.TabIndex = 16
        Me.Button19.Text = "Build 2454 Beta 2"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(3, 459)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(158, 23)
        Me.Button20.TabIndex = 17
        Me.Button20.Text = "Build 2455 Beta 2"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(3, 486)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(158, 23)
        Me.Button21.TabIndex = 18
        Me.Button21.Text = "Build 2457 Beta 2"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(3, 512)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(158, 23)
        Me.Button22.TabIndex = 19
        Me.Button22.Text = "Build 2458 Beta 2"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(3, 537)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(158, 23)
        Me.Button23.TabIndex = 20
        Me.Button23.Text = "Build 2459 Beta 2"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(3, 562)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(158, 23)
        Me.Button24.TabIndex = 21
        Me.Button24.Text = "Build 2462 Beta 2"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(3, 585)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(158, 23)
        Me.Button25.TabIndex = 22
        Me.Button25.Text = "Build 2463 Beta 2"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(3, 610)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(158, 23)
        Me.Button26.TabIndex = 23
        Me.Button26.Text = "Build 2464 Beta 2"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(3, 636)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(158, 23)
        Me.Button27.TabIndex = 24
        Me.Button27.Text = "Build 2465 Beta 2"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(3, 663)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(158, 23)
        Me.Button28.TabIndex = 25
        Me.Button28.Text = "Build 2467 Beta 2"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(3, 689)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(158, 23)
        Me.Button29.TabIndex = 26
        Me.Button29.Text = "Build 2469 Beta 2"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(3, 740)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(158, 23)
        Me.Button30.TabIndex = 27
        Me.Button30.Text = "Build 2474 Pre-RC1"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(3, 763)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(158, 23)
        Me.Button31.TabIndex = 28
        Me.Button31.Text = "Build 2475 Pre-RC1"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(3, 788)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(158, 23)
        Me.Button32.TabIndex = 29
        Me.Button32.Text = "Build 2481 Pre-RC1"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(3, 843)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(158, 23)
        Me.Button33.TabIndex = 30
        Me.Button33.Text = "Build 2485 Pre-RC1"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(3, 817)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(158, 23)
        Me.Button34.TabIndex = 31
        Me.Button34.Text = "Build 2486 Pre-RC1"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.bDown.My.Resources.Resources.XP
        Me.PictureBox2.Location = New System.Drawing.Point(3, 715)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(117, 23)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 32
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.bDown.My.Resources.Resources.Whistler
        Me.PictureBox3.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(126, 25)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 33
        Me.PictureBox3.TabStop = False
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(3, 866)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(158, 23)
        Me.Button35.TabIndex = 34
        Me.Button35.Text = "Build 2494 Pre-RC1"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(3, 892)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(158, 23)
        Me.Button36.TabIndex = 35
        Me.Button36.Text = "Build 2495 Pre-RC1"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(3, 918)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(158, 23)
        Me.Button37.TabIndex = 36
        Me.Button37.Text = "Build 2498 Pre-RC1"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(3, 943)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(158, 23)
        Me.Button38.TabIndex = 37
        Me.Button38.Text = "Build 2499 Pre-RC1"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.Location = New System.Drawing.Point(3, 969)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(158, 23)
        Me.Button39.TabIndex = 38
        Me.Button39.Text = "Build 2502 Pre-RC1"
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.Location = New System.Drawing.Point(3, 995)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(158, 23)
        Me.Button40.TabIndex = 39
        Me.Button40.Text = "Build 2504 Pre-RC1"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.Location = New System.Drawing.Point(3, 1019)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(158, 23)
        Me.Button41.TabIndex = 40
        Me.Button41.Text = "Build 2505 RC1"
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button42
        '
        Me.Button42.Enabled = False
        Me.Button42.Location = New System.Drawing.Point(3, 1045)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(158, 23)
        Me.Button42.TabIndex = 41
        Me.Button42.Text = "Build 2509 RC1 (not found)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.Location = New System.Drawing.Point(3, 1071)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(158, 23)
        Me.Button43.TabIndex = 42
        Me.Button43.Text = "Build 2517 Pre-RC2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button43.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.Location = New System.Drawing.Point(3, 1096)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(158, 23)
        Me.Button44.TabIndex = 43
        Me.Button44.Text = "Build 2520 Pre-RC2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button45
        '
        Me.Button45.Location = New System.Drawing.Point(3, 1122)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(158, 23)
        Me.Button45.TabIndex = 44
        Me.Button45.Text = "Build 2525 Pre-RC2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button46
        '
        Me.Button46.Location = New System.Drawing.Point(3, 1148)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(158, 23)
        Me.Button46.TabIndex = 45
        Me.Button46.Text = "Build 2526 RC2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Button47
        '
        Me.Button47.Location = New System.Drawing.Point(3, 1173)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(158, 23)
        Me.Button47.TabIndex = 46
        Me.Button47.Text = "Build 2531 RC2"
        Me.Button47.UseVisualStyleBackColor = True
        '
        'Button48
        '
        Me.Button48.Location = New System.Drawing.Point(3, 1197)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(158, 23)
        Me.Button48.TabIndex = 47
        Me.Button48.Text = "Build 2532 RC2"
        Me.Button48.UseVisualStyleBackColor = True
        '
        'Button49
        '
        Me.Button49.Location = New System.Drawing.Point(3, 1222)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(158, 23)
        Me.Button49.TabIndex = 48
        Me.Button49.Text = "Build 2535 Pre-RTM"
        Me.Button49.UseVisualStyleBackColor = True
        '
        'Button50
        '
        Me.Button50.Location = New System.Drawing.Point(3, 1248)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(158, 23)
        Me.Button50.TabIndex = 49
        Me.Button50.Text = "Build 2542 Pre-RTM"
        Me.Button50.UseVisualStyleBackColor = True
        '
        'Button51
        '
        Me.Button51.Location = New System.Drawing.Point(3, 1272)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(158, 23)
        Me.Button51.TabIndex = 50
        Me.Button51.Text = "Build 2600 RTM"
        Me.Button51.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = True
        Me.Panel2.BackColor = System.Drawing.Color.AliceBlue
        Me.Panel2.Controls.Add(Me.Button51)
        Me.Panel2.Controls.Add(Me.Button50)
        Me.Panel2.Controls.Add(Me.Button49)
        Me.Panel2.Controls.Add(Me.Button48)
        Me.Panel2.Controls.Add(Me.Button47)
        Me.Panel2.Controls.Add(Me.Button46)
        Me.Panel2.Controls.Add(Me.Button45)
        Me.Panel2.Controls.Add(Me.Button44)
        Me.Panel2.Controls.Add(Me.Button43)
        Me.Panel2.Controls.Add(Me.Button42)
        Me.Panel2.Controls.Add(Me.Button41)
        Me.Panel2.Controls.Add(Me.Button40)
        Me.Panel2.Controls.Add(Me.Button39)
        Me.Panel2.Controls.Add(Me.Button38)
        Me.Panel2.Controls.Add(Me.Button37)
        Me.Panel2.Controls.Add(Me.Button36)
        Me.Panel2.Controls.Add(Me.Button35)
        Me.Panel2.Controls.Add(Me.PictureBox3)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.Button34)
        Me.Panel2.Controls.Add(Me.Button33)
        Me.Panel2.Controls.Add(Me.Button32)
        Me.Panel2.Controls.Add(Me.Button31)
        Me.Panel2.Controls.Add(Me.Button30)
        Me.Panel2.Controls.Add(Me.Button29)
        Me.Panel2.Controls.Add(Me.Button28)
        Me.Panel2.Controls.Add(Me.Button27)
        Me.Panel2.Controls.Add(Me.Button26)
        Me.Panel2.Controls.Add(Me.Button25)
        Me.Panel2.Controls.Add(Me.Button24)
        Me.Panel2.Controls.Add(Me.Button23)
        Me.Panel2.Controls.Add(Me.Button22)
        Me.Panel2.Controls.Add(Me.Button21)
        Me.Panel2.Controls.Add(Me.Button20)
        Me.Panel2.Controls.Add(Me.Button19)
        Me.Panel2.Controls.Add(Me.Button18)
        Me.Panel2.Controls.Add(Me.Button17)
        Me.Panel2.Controls.Add(Me.Button16)
        Me.Panel2.Controls.Add(Me.Button15)
        Me.Panel2.Controls.Add(Me.Button14)
        Me.Panel2.Controls.Add(Me.Button13)
        Me.Panel2.Controls.Add(Me.Button12)
        Me.Panel2.Controls.Add(Me.Button11)
        Me.Panel2.Controls.Add(Me.Button10)
        Me.Panel2.Controls.Add(Me.Button9)
        Me.Panel2.Controls.Add(Me.Button8)
        Me.Panel2.Controls.Add(Me.Button7)
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.Button4)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Location = New System.Drawing.Point(12, 49)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(211, 238)
        Me.Panel2.TabIndex = 3
        '
        'Button52
        '
        Me.Button52.Location = New System.Drawing.Point(4, 4)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(159, 23)
        Me.Button52.TabIndex = 0
        Me.Button52.Text = "Chicago build 58s"
        Me.Button52.UseVisualStyleBackColor = True
        '
        'Button53
        '
        Me.Button53.Location = New System.Drawing.Point(3, 28)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(159, 23)
        Me.Button53.TabIndex = 1
        Me.Button53.Text = "Chicago build 73f"
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Button54
        '
        Me.Button54.Location = New System.Drawing.Point(3, 52)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(159, 23)
        Me.Button54.TabIndex = 2
        Me.Button54.Text = "Chicago build 73g"
        Me.Button54.UseVisualStyleBackColor = True
        '
        'Button55
        '
        Me.Button55.Location = New System.Drawing.Point(3, 76)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(159, 23)
        Me.Button55.TabIndex = 3
        Me.Button55.Text = "Chicago build 81"
        Me.Button55.UseVisualStyleBackColor = True
        '
        'Button56
        '
        Me.Button56.Enabled = False
        Me.Button56.Location = New System.Drawing.Point(3, 100)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(159, 39)
        Me.Button56.TabIndex = 4
        Me.Button56.Text = "Chicago build 89e (only on BetaArchive)"
        Me.Button56.UseVisualStyleBackColor = True
        '
        'Button57
        '
        Me.Button57.Location = New System.Drawing.Point(3, 143)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(159, 22)
        Me.Button57.TabIndex = 5
        Me.Button57.Text = "Chicago build 90c"
        Me.Button57.UseVisualStyleBackColor = True
        '
        'Button58
        '
        Me.Button58.Location = New System.Drawing.Point(3, 165)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(159, 22)
        Me.Button58.TabIndex = 6
        Me.Button58.Text = "Chicago build 99"
        Me.Button58.UseVisualStyleBackColor = True
        '
        'Button59
        '
        Me.Button59.Location = New System.Drawing.Point(3, 187)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(159, 22)
        Me.Button59.TabIndex = 7
        Me.Button59.Text = "Chicago build 116"
        Me.Button59.UseVisualStyleBackColor = True
        '
        'Button60
        '
        Me.Button60.Location = New System.Drawing.Point(3, 209)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(159, 22)
        Me.Button60.TabIndex = 8
        Me.Button60.Text = "Chicago build 122"
        Me.Button60.UseVisualStyleBackColor = True
        '
        'Button61
        '
        Me.Button61.Location = New System.Drawing.Point(3, 231)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(159, 22)
        Me.Button61.TabIndex = 9
        Me.Button61.Text = "Chicago build 180"
        Me.Button61.UseVisualStyleBackColor = True
        '
        'Button62
        '
        Me.Button62.Location = New System.Drawing.Point(3, 253)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(159, 22)
        Me.Button62.TabIndex = 10
        Me.Button62.Text = "Chicago build 189"
        Me.Button62.UseVisualStyleBackColor = True
        '
        'Button63
        '
        Me.Button63.Location = New System.Drawing.Point(3, 277)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(159, 22)
        Me.Button63.TabIndex = 11
        Me.Button63.Text = "Chicago build 216"
        Me.Button63.UseVisualStyleBackColor = True
        '
        'Button64
        '
        Me.Button64.Enabled = False
        Me.Button64.Location = New System.Drawing.Point(3, 300)
        Me.Button64.Name = "Button64"
        Me.Button64.Size = New System.Drawing.Size(159, 36)
        Me.Button64.TabIndex = 12
        Me.Button64.Text = "Chicago build 222 (only on BetaArchive)"
        Me.Button64.UseVisualStyleBackColor = True
        '
        'Button65
        '
        Me.Button65.Location = New System.Drawing.Point(3, 338)
        Me.Button65.Name = "Button65"
        Me.Button65.Size = New System.Drawing.Size(159, 22)
        Me.Button65.TabIndex = 13
        Me.Button65.Text = "Chicago build 224"
        Me.Button65.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.bDown.My.Resources.Resources.MCS
        Me.PictureBox4.Location = New System.Drawing.Point(162, 5)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(31, 226)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 14
        Me.PictureBox4.TabStop = False
        '
        'Button66
        '
        Me.Button66.Enabled = False
        Me.Button66.Location = New System.Drawing.Point(3, 360)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(159, 22)
        Me.Button66.TabIndex = 15
        Me.Button66.Text = "Chicago build 225 (not found)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button66.UseVisualStyleBackColor = True
        '
        'Button67
        '
        Me.Button67.Location = New System.Drawing.Point(3, 381)
        Me.Button67.Name = "Button67"
        Me.Button67.Size = New System.Drawing.Size(159, 22)
        Me.Button67.TabIndex = 16
        Me.Button67.Text = "Chicago build 263"
        Me.Button67.UseVisualStyleBackColor = True
        '
        'Button68
        '
        Me.Button68.Location = New System.Drawing.Point(3, 404)
        Me.Button68.Name = "Button68"
        Me.Button68.Size = New System.Drawing.Size(159, 22)
        Me.Button68.TabIndex = 17
        Me.Button68.Text = "Chicago build 267"
        Me.Button68.UseVisualStyleBackColor = True
        '
        'Button69
        '
        Me.Button69.Location = New System.Drawing.Point(3, 426)
        Me.Button69.Name = "Button69"
        Me.Button69.Size = New System.Drawing.Size(159, 22)
        Me.Button69.TabIndex = 18
        Me.Button69.Text = "Chicago build 275"
        Me.Button69.UseVisualStyleBackColor = True
        '
        'Button70
        '
        Me.Button70.Location = New System.Drawing.Point(3, 450)
        Me.Button70.Name = "Button70"
        Me.Button70.Size = New System.Drawing.Size(159, 22)
        Me.Button70.TabIndex = 19
        Me.Button70.Text = "Chicago build 285"
        Me.Button70.UseVisualStyleBackColor = True
        '
        'Button71
        '
        Me.Button71.Location = New System.Drawing.Point(3, 473)
        Me.Button71.Name = "Button71"
        Me.Button71.Size = New System.Drawing.Size(159, 22)
        Me.Button71.TabIndex = 20
        Me.Button71.Text = "Chicago build 286"
        Me.Button71.UseVisualStyleBackColor = True
        '
        'Button72
        '
        Me.Button72.Location = New System.Drawing.Point(3, 494)
        Me.Button72.Name = "Button72"
        Me.Button72.Size = New System.Drawing.Size(159, 22)
        Me.Button72.TabIndex = 21
        Me.Button72.Text = "Chicago build 302"
        Me.Button72.UseVisualStyleBackColor = True
        '
        'Button73
        '
        Me.Button73.Enabled = False
        Me.Button73.Location = New System.Drawing.Point(3, 519)
        Me.Button73.Name = "Button73"
        Me.Button73.Size = New System.Drawing.Size(159, 36)
        Me.Button73.TabIndex = 22
        Me.Button73.Text = "Chicago build 310 (only on BetaArchive)"
        Me.Button73.UseVisualStyleBackColor = True
        '
        'Button74
        '
        Me.Button74.Location = New System.Drawing.Point(3, 555)
        Me.Button74.Name = "Button74"
        Me.Button74.Size = New System.Drawing.Size(159, 22)
        Me.Button74.TabIndex = 23
        Me.Button74.Text = "Chicago build 311"
        Me.Button74.UseVisualStyleBackColor = True
        '
        'Button75
        '
        Me.Button75.Location = New System.Drawing.Point(3, 577)
        Me.Button75.Name = "Button75"
        Me.Button75.Size = New System.Drawing.Size(159, 22)
        Me.Button75.TabIndex = 24
        Me.Button75.Text = "Chicago build 314"
        Me.Button75.UseVisualStyleBackColor = True
        '
        'Button76
        '
        Me.Button76.Location = New System.Drawing.Point(3, 599)
        Me.Button76.Name = "Button76"
        Me.Button76.Size = New System.Drawing.Size(159, 22)
        Me.Button76.TabIndex = 25
        Me.Button76.Text = "Chicago build 318"
        Me.Button76.UseVisualStyleBackColor = True
        '
        'Button77
        '
        Me.Button77.Enabled = False
        Me.Button77.Location = New System.Drawing.Point(3, 624)
        Me.Button77.Name = "Button77"
        Me.Button77.Size = New System.Drawing.Size(159, 22)
        Me.Button77.TabIndex = 26
        Me.Button77.Text = "Chicago build 323 (not found)"
        Me.Button77.UseVisualStyleBackColor = True
        '
        'Button78
        '
        Me.Button78.Location = New System.Drawing.Point(3, 647)
        Me.Button78.Name = "Button78"
        Me.Button78.Size = New System.Drawing.Size(159, 22)
        Me.Button78.TabIndex = 27
        Me.Button78.Text = "Chicago build 324"
        Me.Button78.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.AutoScroll = True
        Me.Panel4.BackColor = System.Drawing.Color.AliceBlue
        Me.Panel4.Controls.Add(Me.Button111)
        Me.Panel4.Controls.Add(Me.Button110)
        Me.Panel4.Controls.Add(Me.Button109)
        Me.Panel4.Controls.Add(Me.Button108)
        Me.Panel4.Controls.Add(Me.Button107)
        Me.Panel4.Controls.Add(Me.Button105)
        Me.Panel4.Controls.Add(Me.Button104)
        Me.Panel4.Controls.Add(Me.Button103)
        Me.Panel4.Controls.Add(Me.Button102)
        Me.Panel4.Controls.Add(Me.Button78)
        Me.Panel4.Controls.Add(Me.Button77)
        Me.Panel4.Controls.Add(Me.Button76)
        Me.Panel4.Controls.Add(Me.Button75)
        Me.Panel4.Controls.Add(Me.Button74)
        Me.Panel4.Controls.Add(Me.Button73)
        Me.Panel4.Controls.Add(Me.Button72)
        Me.Panel4.Controls.Add(Me.Button71)
        Me.Panel4.Controls.Add(Me.Button70)
        Me.Panel4.Controls.Add(Me.Button69)
        Me.Panel4.Controls.Add(Me.Button68)
        Me.Panel4.Controls.Add(Me.Button67)
        Me.Panel4.Controls.Add(Me.Button66)
        Me.Panel4.Controls.Add(Me.PictureBox4)
        Me.Panel4.Controls.Add(Me.Button65)
        Me.Panel4.Controls.Add(Me.Button64)
        Me.Panel4.Controls.Add(Me.Button63)
        Me.Panel4.Controls.Add(Me.Button62)
        Me.Panel4.Controls.Add(Me.Button61)
        Me.Panel4.Controls.Add(Me.Button60)
        Me.Panel4.Controls.Add(Me.Button59)
        Me.Panel4.Controls.Add(Me.Button58)
        Me.Panel4.Controls.Add(Me.Button57)
        Me.Panel4.Controls.Add(Me.Button56)
        Me.Panel4.Controls.Add(Me.Button55)
        Me.Panel4.Controls.Add(Me.Button54)
        Me.Panel4.Controls.Add(Me.Button53)
        Me.Panel4.Controls.Add(Me.Button52)
        Me.Panel4.Location = New System.Drawing.Point(235, 155)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(211, 132)
        Me.Panel4.TabIndex = 51
        '
        'Button111
        '
        Me.Button111.Location = New System.Drawing.Point(3, 896)
        Me.Button111.Name = "Button111"
        Me.Button111.Size = New System.Drawing.Size(159, 23)
        Me.Button111.TabIndex = 36
        Me.Button111.Text = "Chicago build 420"
        Me.Button111.UseVisualStyleBackColor = True
        '
        'Button110
        '
        Me.Button110.Enabled = False
        Me.Button110.Location = New System.Drawing.Point(3, 856)
        Me.Button110.Name = "Button110"
        Me.Button110.Size = New System.Drawing.Size(159, 37)
        Me.Button110.TabIndex = 35
        Me.Button110.Text = "Chicago build 411 (only on BetaArchive)"
        Me.Button110.UseVisualStyleBackColor = True
        '
        'Button109
        '
        Me.Button109.Location = New System.Drawing.Point(3, 832)
        Me.Button109.Name = "Button109"
        Me.Button109.Size = New System.Drawing.Size(159, 23)
        Me.Button109.TabIndex = 34
        Me.Button109.Text = "Chicago build 405"
        Me.Button109.UseVisualStyleBackColor = True
        '
        'Button108
        '
        Me.Button108.Location = New System.Drawing.Point(3, 808)
        Me.Button108.Name = "Button108"
        Me.Button108.Size = New System.Drawing.Size(159, 23)
        Me.Button108.TabIndex = 33
        Me.Button108.Text = "Chicago build 347"
        Me.Button108.UseVisualStyleBackColor = True
        '
        'Button107
        '
        Me.Button107.Location = New System.Drawing.Point(3, 783)
        Me.Button107.Name = "Button107"
        Me.Button107.Size = New System.Drawing.Size(159, 23)
        Me.Button107.TabIndex = 32
        Me.Button107.Text = "Chicago build 345"
        Me.Button107.UseVisualStyleBackColor = True
        '
        'Button105
        '
        Me.Button105.Location = New System.Drawing.Point(3, 759)
        Me.Button105.Name = "Button105"
        Me.Button105.Size = New System.Drawing.Size(159, 23)
        Me.Button105.TabIndex = 31
        Me.Button105.Text = "Chicago build 342"
        Me.Button105.UseVisualStyleBackColor = True
        '
        'Button104
        '
        Me.Button104.Location = New System.Drawing.Point(3, 735)
        Me.Button104.Name = "Button104"
        Me.Button104.Size = New System.Drawing.Size(159, 23)
        Me.Button104.TabIndex = 30
        Me.Button104.Text = "Chicago build 337"
        Me.Button104.UseVisualStyleBackColor = True
        '
        'Button103
        '
        Me.Button103.Location = New System.Drawing.Point(3, 710)
        Me.Button103.Name = "Button103"
        Me.Button103.Size = New System.Drawing.Size(159, 23)
        Me.Button103.TabIndex = 29
        Me.Button103.Text = "Chicago build 331"
        Me.Button103.UseVisualStyleBackColor = True
        '
        'Button102
        '
        Me.Button102.Enabled = False
        Me.Button102.Location = New System.Drawing.Point(3, 671)
        Me.Button102.Name = "Button102"
        Me.Button102.Size = New System.Drawing.Size(159, 36)
        Me.Button102.TabIndex = 28
        Me.Button102.Text = "Chicago build 328 (only on BetaArchive)"
        Me.Button102.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.AutoScroll = True
        Me.Panel5.BackColor = System.Drawing.Color.AliceBlue
        Me.Panel5.Controls.Add(Me.Button118)
        Me.Panel5.Controls.Add(Me.Button117)
        Me.Panel5.Controls.Add(Me.Button116)
        Me.Panel5.Controls.Add(Me.Button115)
        Me.Panel5.Controls.Add(Me.Button114)
        Me.Panel5.Controls.Add(Me.Button113)
        Me.Panel5.Controls.Add(Me.Button112)
        Me.Panel5.Controls.Add(Me.PictureBox5)
        Me.Panel5.Controls.Add(Me.Button100)
        Me.Panel5.Controls.Add(Me.Button99)
        Me.Panel5.Controls.Add(Me.Button98)
        Me.Panel5.Controls.Add(Me.Button97)
        Me.Panel5.Controls.Add(Me.Button96)
        Me.Panel5.Controls.Add(Me.Button95)
        Me.Panel5.Controls.Add(Me.Button94)
        Me.Panel5.Controls.Add(Me.Button93)
        Me.Panel5.Controls.Add(Me.Button92)
        Me.Panel5.Controls.Add(Me.Button91)
        Me.Panel5.Controls.Add(Me.Button90)
        Me.Panel5.Controls.Add(Me.Button89)
        Me.Panel5.Controls.Add(Me.Button88)
        Me.Panel5.Controls.Add(Me.Button87)
        Me.Panel5.Controls.Add(Me.Button86)
        Me.Panel5.Controls.Add(Me.Button85)
        Me.Panel5.Controls.Add(Me.Button84)
        Me.Panel5.Controls.Add(Me.Button83)
        Me.Panel5.Controls.Add(Me.Button82)
        Me.Panel5.Controls.Add(Me.Button81)
        Me.Panel5.Controls.Add(Me.Button80)
        Me.Panel5.Controls.Add(Me.Button79)
        Me.Panel5.Location = New System.Drawing.Point(12, 320)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(224, 189)
        Me.Panel5.TabIndex = 59
        '
        'Button118
        '
        Me.Button118.Location = New System.Drawing.Point(12, 731)
        Me.Button118.Name = "Button118"
        Me.Button118.Size = New System.Drawing.Size(150, 24)
        Me.Button118.TabIndex = 29
        Me.Button118.Text = "Memphis build 1624"
        Me.Button118.UseVisualStyleBackColor = True
        '
        'Button117
        '
        Me.Button117.Location = New System.Drawing.Point(12, 706)
        Me.Button117.Name = "Button117"
        Me.Button117.Size = New System.Drawing.Size(150, 24)
        Me.Button117.TabIndex = 28
        Me.Button117.Text = "Memphis build 1619" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button117.UseVisualStyleBackColor = True
        '
        'Button116
        '
        Me.Button116.Location = New System.Drawing.Point(12, 679)
        Me.Button116.Name = "Button116"
        Me.Button116.Size = New System.Drawing.Size(150, 24)
        Me.Button116.TabIndex = 27
        Me.Button116.Text = "Memphis build 1614" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button116.UseVisualStyleBackColor = True
        '
        'Button115
        '
        Me.Button115.Location = New System.Drawing.Point(12, 652)
        Me.Button115.Name = "Button115"
        Me.Button115.Size = New System.Drawing.Size(150, 24)
        Me.Button115.TabIndex = 26
        Me.Button115.Text = "Memphis build 1602" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button115.UseVisualStyleBackColor = True
        '
        'Button114
        '
        Me.Button114.Location = New System.Drawing.Point(12, 627)
        Me.Button114.Name = "Button114"
        Me.Button114.Size = New System.Drawing.Size(150, 24)
        Me.Button114.TabIndex = 25
        Me.Button114.Text = "Memphis build 1593"
        Me.Button114.UseVisualStyleBackColor = True
        '
        'Button113
        '
        Me.Button113.Location = New System.Drawing.Point(12, 599)
        Me.Button113.Name = "Button113"
        Me.Button113.Size = New System.Drawing.Size(150, 24)
        Me.Button113.TabIndex = 24
        Me.Button113.Text = "Memphis build 1581.1"
        Me.Button113.UseVisualStyleBackColor = True
        '
        'Button112
        '
        Me.Button112.Location = New System.Drawing.Point(12, 571)
        Me.Button112.Name = "Button112"
        Me.Button112.Size = New System.Drawing.Size(150, 24)
        Me.Button112.TabIndex = 23
        Me.Button112.Text = "Memphis build 1577"
        Me.Button112.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.bDown.My.Resources.Resources.MCS
        Me.PictureBox5.Location = New System.Drawing.Point(163, 6)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(42, 226)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 22
        Me.PictureBox5.TabStop = False
        '
        'Button100
        '
        Me.Button100.Location = New System.Drawing.Point(12, 544)
        Me.Button100.Name = "Button100"
        Me.Button100.Size = New System.Drawing.Size(150, 24)
        Me.Button100.TabIndex = 21
        Me.Button100.Text = "Memphis build 1569" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button100.UseVisualStyleBackColor = True
        '
        'Button99
        '
        Me.Button99.Location = New System.Drawing.Point(12, 514)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(150, 24)
        Me.Button99.TabIndex = 20
        Me.Button99.Text = "Memphis build 1559" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button99.UseVisualStyleBackColor = True
        '
        'Button98
        '
        Me.Button98.Location = New System.Drawing.Point(12, 486)
        Me.Button98.Name = "Button98"
        Me.Button98.Size = New System.Drawing.Size(150, 24)
        Me.Button98.TabIndex = 19
        Me.Button98.Text = "Memphis build 1546" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button98.UseVisualStyleBackColor = True
        '
        'Button97
        '
        Me.Button97.Location = New System.Drawing.Point(12, 459)
        Me.Button97.Name = "Button97"
        Me.Button97.Size = New System.Drawing.Size(150, 24)
        Me.Button97.TabIndex = 18
        Me.Button97.Text = "Memphis build 1544" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button97.UseVisualStyleBackColor = True
        '
        'Button96
        '
        Me.Button96.Location = New System.Drawing.Point(12, 434)
        Me.Button96.Name = "Button96"
        Me.Button96.Size = New System.Drawing.Size(150, 24)
        Me.Button96.TabIndex = 17
        Me.Button96.Text = "Memphis build 1538" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button96.UseVisualStyleBackColor = True
        '
        'Button95
        '
        Me.Button95.Location = New System.Drawing.Point(12, 396)
        Me.Button95.Name = "Button95"
        Me.Button95.Size = New System.Drawing.Size(150, 35)
        Me.Button95.TabIndex = 16
        Me.Button95.Text = "Memphis build 1532 (download at your own risk)"
        Me.Button95.UseVisualStyleBackColor = True
        '
        'Button94
        '
        Me.Button94.Location = New System.Drawing.Point(12, 371)
        Me.Button94.Name = "Button94"
        Me.Button94.Size = New System.Drawing.Size(150, 23)
        Me.Button94.TabIndex = 15
        Me.Button94.Text = "Memphis build 1526"
        Me.Button94.UseVisualStyleBackColor = True
        '
        'Button93
        '
        Me.Button93.Location = New System.Drawing.Point(12, 348)
        Me.Button93.Name = "Button93"
        Me.Button93.Size = New System.Drawing.Size(150, 23)
        Me.Button93.TabIndex = 14
        Me.Button93.Text = "Memphis build 1525"
        Me.Button93.UseVisualStyleBackColor = True
        '
        'Button92
        '
        Me.Button92.Location = New System.Drawing.Point(12, 324)
        Me.Button92.Name = "Button92"
        Me.Button92.Size = New System.Drawing.Size(150, 23)
        Me.Button92.TabIndex = 13
        Me.Button92.Text = "Memphis build 1518"
        Me.Button92.UseVisualStyleBackColor = True
        '
        'Button91
        '
        Me.Button91.Location = New System.Drawing.Point(12, 298)
        Me.Button91.Name = "Button91"
        Me.Button91.Size = New System.Drawing.Size(150, 23)
        Me.Button91.TabIndex = 12
        Me.Button91.Text = "Memphis build 1513" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button91.UseVisualStyleBackColor = True
        '
        'Button90
        '
        Me.Button90.Location = New System.Drawing.Point(12, 275)
        Me.Button90.Name = "Button90"
        Me.Button90.Size = New System.Drawing.Size(150, 23)
        Me.Button90.TabIndex = 11
        Me.Button90.Text = "Memphis build 1511"
        Me.Button90.UseVisualStyleBackColor = True
        '
        'Button89
        '
        Me.Button89.Location = New System.Drawing.Point(12, 251)
        Me.Button89.Name = "Button89"
        Me.Button89.Size = New System.Drawing.Size(150, 23)
        Me.Button89.TabIndex = 10
        Me.Button89.Text = "Memphis build 1500"
        Me.Button89.UseVisualStyleBackColor = True
        '
        'Button88
        '
        Me.Button88.Location = New System.Drawing.Point(12, 230)
        Me.Button88.Name = "Button88"
        Me.Button88.Size = New System.Drawing.Size(150, 23)
        Me.Button88.TabIndex = 9
        Me.Button88.Text = "Memphis build 1488" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button88.UseVisualStyleBackColor = True
        '
        'Button87
        '
        Me.Button87.Location = New System.Drawing.Point(12, 205)
        Me.Button87.Name = "Button87"
        Me.Button87.Size = New System.Drawing.Size(150, 23)
        Me.Button87.TabIndex = 8
        Me.Button87.Text = "Memphis build 1434" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button87.UseVisualStyleBackColor = True
        '
        'Button86
        '
        Me.Button86.Location = New System.Drawing.Point(12, 181)
        Me.Button86.Name = "Button86"
        Me.Button86.Size = New System.Drawing.Size(150, 23)
        Me.Button86.TabIndex = 7
        Me.Button86.Text = "Memphis build 1423" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button86.UseVisualStyleBackColor = True
        '
        'Button85
        '
        Me.Button85.Location = New System.Drawing.Point(12, 155)
        Me.Button85.Name = "Button85"
        Me.Button85.Size = New System.Drawing.Size(150, 23)
        Me.Button85.TabIndex = 6
        Me.Button85.Text = "Memphis build 1415" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button85.UseVisualStyleBackColor = True
        '
        'Button84
        '
        Me.Button84.Location = New System.Drawing.Point(12, 129)
        Me.Button84.Name = "Button84"
        Me.Button84.Size = New System.Drawing.Size(150, 23)
        Me.Button84.TabIndex = 5
        Me.Button84.Text = "Memphis build 1411"
        Me.Button84.UseVisualStyleBackColor = True
        '
        'Button83
        '
        Me.Button83.Location = New System.Drawing.Point(12, 104)
        Me.Button83.Name = "Button83"
        Me.Button83.Size = New System.Drawing.Size(150, 23)
        Me.Button83.TabIndex = 4
        Me.Button83.Text = "Memphis build 1410" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button83.UseVisualStyleBackColor = True
        '
        'Button82
        '
        Me.Button82.Location = New System.Drawing.Point(12, 79)
        Me.Button82.Name = "Button82"
        Me.Button82.Size = New System.Drawing.Size(150, 23)
        Me.Button82.TabIndex = 3
        Me.Button82.Text = "Memphis build 1400" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button82.UseVisualStyleBackColor = True
        '
        'Button81
        '
        Me.Button81.Location = New System.Drawing.Point(12, 53)
        Me.Button81.Name = "Button81"
        Me.Button81.Size = New System.Drawing.Size(150, 23)
        Me.Button81.TabIndex = 2
        Me.Button81.Text = "Memphis build 1387"
        Me.Button81.UseVisualStyleBackColor = True
        '
        'Button80
        '
        Me.Button80.Location = New System.Drawing.Point(12, 29)
        Me.Button80.Name = "Button80"
        Me.Button80.Size = New System.Drawing.Size(150, 23)
        Me.Button80.TabIndex = 1
        Me.Button80.Text = "Memphis build 1353"
        Me.Button80.UseVisualStyleBackColor = True
        '
        'Button79
        '
        Me.Button79.Location = New System.Drawing.Point(12, 5)
        Me.Button79.Name = "Button79"
        Me.Button79.Size = New System.Drawing.Size(150, 23)
        Me.Button79.TabIndex = 0
        Me.Button79.Text = "Memphis build 1351"
        Me.Button79.UseVisualStyleBackColor = True
        '
        'Button106
        '
        Me.Button106.Enabled = False
        Me.Button106.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button106.Location = New System.Drawing.Point(12, 504)
        Me.Button106.Name = "Button106"
        Me.Button106.Size = New System.Drawing.Size(224, 37)
        Me.Button106.TabIndex = 60
        Me.Button106.Text = "Windows Memphis"
        Me.Button106.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(452, 347)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(241, 26)
        Me.Label7.TabIndex = 61
        Me.Label7.Text = "Download at your own risk means that this build is" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "embedded with a Virus."
        '
        'Button119
        '
        Me.Button119.Enabled = False
        Me.Button119.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button119.Location = New System.Drawing.Point(238, 504)
        Me.Button119.Name = "Button119"
        Me.Button119.Size = New System.Drawing.Size(208, 37)
        Me.Button119.TabIndex = 62
        Me.Button119.Text = "Windows Mantis"
        Me.Button119.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.AutoScroll = True
        Me.Panel6.BackColor = System.Drawing.Color.AliceBlue
        Me.Panel6.Controls.Add(Me.Button120)
        Me.Panel6.Location = New System.Drawing.Point(238, 320)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(205, 189)
        Me.Panel6.TabIndex = 60
        '
        'Button120
        '
        Me.Button120.Location = New System.Drawing.Point(5, 8)
        Me.Button120.Name = "Button120"
        Me.Button120.Size = New System.Drawing.Size(185, 23)
        Me.Button120.TabIndex = 0
        Me.Button120.Text = "Windows XP Embedded 2526"
        Me.Button120.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SkyBlue
        Me.ClientSize = New System.Drawing.Size(712, 537)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Button119)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Button106)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button101)
        Me.Controls.Add(Me.Label8)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "bDown"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button101 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button52 As System.Windows.Forms.Button
    Friend WithEvents Button53 As System.Windows.Forms.Button
    Friend WithEvents Button54 As System.Windows.Forms.Button
    Friend WithEvents Button55 As System.Windows.Forms.Button
    Friend WithEvents Button56 As System.Windows.Forms.Button
    Friend WithEvents Button57 As System.Windows.Forms.Button
    Friend WithEvents Button58 As System.Windows.Forms.Button
    Friend WithEvents Button59 As System.Windows.Forms.Button
    Friend WithEvents Button60 As System.Windows.Forms.Button
    Friend WithEvents Button61 As System.Windows.Forms.Button
    Friend WithEvents Button62 As System.Windows.Forms.Button
    Friend WithEvents Button63 As System.Windows.Forms.Button
    Friend WithEvents Button64 As System.Windows.Forms.Button
    Friend WithEvents Button65 As System.Windows.Forms.Button
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents Button66 As System.Windows.Forms.Button
    Friend WithEvents Button67 As System.Windows.Forms.Button
    Friend WithEvents Button68 As System.Windows.Forms.Button
    Friend WithEvents Button69 As System.Windows.Forms.Button
    Friend WithEvents Button70 As System.Windows.Forms.Button
    Friend WithEvents Button71 As System.Windows.Forms.Button
    Friend WithEvents Button72 As System.Windows.Forms.Button
    Friend WithEvents Button73 As System.Windows.Forms.Button
    Friend WithEvents Button74 As System.Windows.Forms.Button
    Friend WithEvents Button75 As System.Windows.Forms.Button
    Friend WithEvents Button76 As System.Windows.Forms.Button
    Friend WithEvents Button77 As System.Windows.Forms.Button
    Friend WithEvents Button78 As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Button79 As System.Windows.Forms.Button
    Friend WithEvents Button106 As System.Windows.Forms.Button
    Friend WithEvents Button80 As System.Windows.Forms.Button
    Friend WithEvents Button81 As System.Windows.Forms.Button
    Friend WithEvents Button82 As System.Windows.Forms.Button
    Friend WithEvents Button83 As System.Windows.Forms.Button
    Friend WithEvents Button84 As System.Windows.Forms.Button
    Friend WithEvents Button85 As System.Windows.Forms.Button
    Friend WithEvents Button86 As System.Windows.Forms.Button
    Friend WithEvents Button87 As System.Windows.Forms.Button
    Friend WithEvents Button88 As System.Windows.Forms.Button
    Friend WithEvents Button89 As System.Windows.Forms.Button
    Friend WithEvents Button90 As System.Windows.Forms.Button
    Friend WithEvents Button91 As System.Windows.Forms.Button
    Friend WithEvents Button92 As System.Windows.Forms.Button
    Friend WithEvents Button93 As System.Windows.Forms.Button
    Friend WithEvents Button94 As System.Windows.Forms.Button
    Friend WithEvents Button95 As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Button96 As System.Windows.Forms.Button
    Friend WithEvents Button97 As System.Windows.Forms.Button
    Friend WithEvents Button98 As System.Windows.Forms.Button
    Friend WithEvents Button99 As System.Windows.Forms.Button
    Friend WithEvents Button100 As System.Windows.Forms.Button
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Button103 As System.Windows.Forms.Button
    Friend WithEvents Button102 As System.Windows.Forms.Button
    Friend WithEvents Button104 As System.Windows.Forms.Button
    Friend WithEvents Button105 As System.Windows.Forms.Button
    Friend WithEvents Button107 As System.Windows.Forms.Button
    Friend WithEvents Button108 As System.Windows.Forms.Button
    Friend WithEvents Button109 As System.Windows.Forms.Button
    Friend WithEvents Button111 As System.Windows.Forms.Button
    Friend WithEvents Button110 As System.Windows.Forms.Button
    Friend WithEvents Button112 As System.Windows.Forms.Button
    Friend WithEvents Button113 As System.Windows.Forms.Button
    Friend WithEvents Button114 As System.Windows.Forms.Button
    Friend WithEvents Button115 As System.Windows.Forms.Button
    Friend WithEvents Button116 As System.Windows.Forms.Button
    Friend WithEvents Button117 As System.Windows.Forms.Button
    Friend WithEvents Button118 As System.Windows.Forms.Button
    Friend WithEvents Button119 As System.Windows.Forms.Button
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Button120 As System.Windows.Forms.Button

End Class
